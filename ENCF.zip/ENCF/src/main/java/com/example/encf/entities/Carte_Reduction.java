package com.example.encf.entities;

import jakarta.persistence.Entity;

@Entity

public class Carte_Reduction extends Carte{
    private String type;
}
