package com.example.encf.entities;

public class Carte_Abonnement {
}
