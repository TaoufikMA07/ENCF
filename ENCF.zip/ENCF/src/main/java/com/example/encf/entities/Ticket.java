package com.example.encf.entities;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import org.springframework.boot.autoconfigure.web.WebProperties;

import java.util.Date;

@Entity
public class Ticket {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long id;
    private Gare gare_depart ;

    private Gare gare_arrivee;

    private float prix;

    private Date date_depart;

    private Date date_arrivee;

    private int Num_Place;

    private int Num_Wagon;

    private int Classe ;

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public Gare getGare_depart() {
        return gare_depart;
    }

    public void setGare_depart(Gare gare_depart) {
        this.gare_depart = gare_depart;
    }

    public Gare getGare_arrivee() {
        return gare_arrivee;
    }

    public void setGare_arrivee(Gare gare_arrivee) {
        this.gare_arrivee = gare_arrivee;
    }

    public float getPrix() {
        return prix;
    }

    public void setPrix(float prix) {
        this.prix = prix;
    }

    public Date getDate_depart() {
        return date_depart;
    }

    public void setDate_depart(Date date_depart) {
        this.date_depart = date_depart;
    }

    public Date getDate_arrivee() {
        return date_arrivee;
    }

    public void setDate_arrivee(Date date_arrivee) {
        this.date_arrivee = date_arrivee;
    }

    public int getNum_Place() {
        return Num_Place;
    }

    public void setNum_Place(int num_Place) {
        Num_Place = num_Place;
    }

    public int getNum_Wagon() {
        return Num_Wagon;
    }

    public void setNum_Wagon(int num_Wagon) {
        Num_Wagon = num_Wagon;
    }

    public int getClasse() {
        return Classe;
    }

    public void setClasse(int classe) {
        Classe = classe;
    }
}
