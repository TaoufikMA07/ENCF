package com.example.encf.entities;

import jakarta.persistence.*;

import java.util.Date;

@Entity
@Table(name="Cartes")
public class Carte {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long IdCarte;
    private Date Date_Creation;
    private Date Date_Fin;

    private float Taux_Reduction;

    public long getIdCarte() {
        return IdCarte;
    }

    public void setIdCarte(long idCarte) {
        IdCarte = idCarte;
    }

    public Date getDate_Creation() {
        return Date_Creation;
    }

    public void setDate_Creation(Date date_Creation) {
        Date_Creation = date_Creation;
    }

    public Date getDate_Fin() {
        return Date_Fin;
    }

    public void setDate_Fin(Date date_Fin) {
        Date_Fin = date_Fin;
    }

    public float getTaux_Reduction() {
        return Taux_Reduction;
    }

    public void setTaux_Reduction(float taux_Reduction) {
        Taux_Reduction = taux_Reduction;
    }
}
